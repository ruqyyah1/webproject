# BudgetBuddy
Team name : ECO$OLUTIONS
Members name and student numbers :
	AL-Frenn Mathew, 300356097
	El Yacoubi Lina, 300350357
	Hassan Ruqyyah, 300383524
	Malek Melanie, 300351596
	Saleh Assim, 300353938
Product name: BudgetBuddy
Brief description of our product:
It is a financial Tracker App/website for budgeting for university students. It is meant to help student manage their finances between roommates including paying the rent, the groceries, the bills and many others. The app/website can pull data from banks, but only with an authorization.

